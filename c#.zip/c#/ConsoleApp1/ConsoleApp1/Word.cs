﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //IComparable - интерфейс, который исользуется, чтобы можно было сортировать массив (список) элементов класса Word
    [Serializable]
    public class Word : IComparable<Word>
    {
        private string thisword; //слово
        private int[] pages; //номера страниц, на которых встречается слово
        private int totalPages; // количество уникальных номеров страниц,на которых встречается слово

        //объявление свойств и их методов set get
        //нужны для доступа к закрытым свойствам класса
        public string Thisword
        {
            get
            {
                return thisword;
            }
            set
            {
                thisword = value;
            }
        }
        public int[] Pages {
            get {
                return pages;
            }
            set
            {
                pages = value;
            }
        }
        public int TotalPages {
            get
            {
                return totalPages;
            }
            set
            {
                totalPages = value;
            }
        }


        // стандартный конструктор без параметров
        public Word()
        {
        }

        public Word(string word, int[] pages)
        {
            this.thisword = word;
            Array.Sort(pages);
            this.pages = (int[])pages.Clone();
            this.totalPages = this.getUniquePages().Length;
        }

        //метод для вывода общей информации
        public void show()
        {
            Console.WriteLine("Слово: " + this.thisword + "\nКоличество страниц, на которых встречается: " + this.totalPages);
            if (this.totalPages > 0)
            {
                Console.WriteLine("Всего встречается: " + this.pages.Length + "\nВстречается на страницах: " + this.showPages(this.pages));
            }
            Console.WriteLine();
        }

        //вывести список страниц
        public String showPages(int[] pages)
        {
            String output = "";
            String str = ", ";
            for (int i = 0; i < pages.Length; i++)
            {
                if (i == pages.Length - 1) str = "";
                output += pages[i] + str;
            }
            return output;
        }

        //возвращает массив с уникальными (неповторяющимися) номерами страниц, на которых встречалось слово
        public int[] getUniquePages()
        {
            int[] uniquePages = new int[this.pages.Length];
            int count = 0;
            //если слово не встречалось до этого на текущей странице(отсуствует в массиве uniquePages), то номер страницы добавлется в массив uniquePages
            if (this.pages.Length > 0)
            {
                uniquePages[0] = this.pages[0];
                count++;
            }
            for (int i = 1; i < this.pages.Length; i++)
            {
                bool flag = true;
                for (int j = 0; j < count; j++)
                {
                    if (uniquePages[j] == this.pages[i])
                    {
                        flag= false;
                        break;
                    }
                }
                if (flag)
                {
                    uniquePages[count] = this.pages[i];
                    count++;
                }
            }
            int[] uniqueNew = new int[count];
            for (int i = 0; i < count; i++)
            {
                uniqueNew[i] = uniquePages[i];
            }
            return uniqueNew;
        }

        //сколько всего раз слово встретилось 
        public int calculateMatches()
        {
            return this.pages.Length;
        }

        //перегруженный метод из интерфейса IComparable
        public int CompareTo(Word w)
        {
            if (w == null)
                return 1;
            else
                return this.thisword.CompareTo(w.Thisword);
        }
    }
}
