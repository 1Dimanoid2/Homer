﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    class MainClass
    {
        //список объектов типа Word
        private static List<Word> words = new List<Word> { };
        //список доступных слов:
        private static List<string> vocabulary = new List<string>() {
                "Воздух", "Животное", "Птица", "Тело",
                "Машина", "Ребенок", "День",
                "Собака", "Дверь", "Лицо",
                "Ферма", "Рыба", "Еда", "Дом", "Лошадь"
            };

        static void Main(string[] args)
        {
            const int MAX_COUNT = 10;//максимальное число, сколько раз может встречаться слово
            const int MAX_MATCH = 30; //максимальное количество раз, когда встречается слово

            Random rand = new Random();
            //заполнение списка  объектов типа Word
            for (int i = 0; i < vocabulary.Count; i++)
            {
                int countMatch = rand.Next(MAX_MATCH);//сколько раз слово встретилось от 1 до MAX_MATCH
                int[] pages = new int[countMatch];//на каких страницах оно встретилось
                for (int j = 0; j < countMatch; j++)
                {
                    pages[j] = rand.Next(1, MAX_COUNT - 1);
                }
                words.Insert(i, new Word(vocabulary[i], pages)); //добавить новый элемент в список
                words[i].show(); //показать его
            }
            Console.WriteLine("--------------------------------------------------");

            //файл, куда сохраняются данные объектов при сериализации
            string xmlfile = "./Words.xml";
            //Сохраняем состояние объекта superHuman в XML формате (не сохраняет данные с модификатором private)
            XmlSerializer xml = new XmlSerializer(typeof(List<Word>));
            using (var fStream = new FileStream(xmlfile, FileMode.Create))
            {
                xml.Serialize(fStream, words);
                Console.WriteLine("Данные сериализированы в xml.");
            }
            //очистим список words
            words.RemoveRange(0, words.Count);
            //Данные загрузим и десериализируем
            using (FileStream fs = new FileStream(xmlfile, FileMode.OpenOrCreate))
            {
                //List<Word> newwords = (List<Word>)xml.Deserialize(fs);
                words = (List<Word>)xml.Deserialize(fs);
                Console.WriteLine("Данные десериализированы из xml.");
            }

            Console.WriteLine("--------------------------------------------------");

            //1 задание
            Console.Write("Вывод слов, которые встречаются на страницах более, чем введенное количество раз\nВведите значение: ");
            while (true)
            {
                string str1 = Console.ReadLine();
                try
                {
                    int number1 = Int32.Parse(str1);
                    zadanie1(number1);
                    break;
                }
                catch
                {
                    Console.Write("Неверный формат целого числа! Повторите попытку: ");
                }

            }
            Console.WriteLine("--------------------------------------------------");

            //2 
            zadanie2();
            Console.WriteLine("--------------------------------------------------");

            //3
            //вывести все слова
            String output = "";
            for (int i = 0; i < words.Count; i++)
            {
                output += (i+1) + ")" + words[i].Thisword + " ";
            }
            Console.WriteLine(output);
            //выбрать нужное слово
            int number2;
            Console.Write("Вывод номеров страниц, на которых встречается выбранное слово.\nВведите номер слова: ");
            //цикл будет выполняться, пока не будет введен правильный номер
            while (true)
            {
                string str2 = Console.ReadLine();//считать введенное число
                try
                {
                    number2 = Int32.Parse(str2)-1;//преобразовать его в целое число
                    if (number2 >= words.Count || number2 < 0)
                    {
                        Console.Write("Неверный формат целого числа! Повторите попытку: ");
                    }
                    else//было введено верное число, можно выйти из цикла
                        break;
                }
                catch
                {
                    Console.Write("Неверный формат целого числа! Повторите попытку: ");
                }
            }
            zadanie3(number2);

            Console.ReadLine();
        }

        //1) слова, которые встречаются больше N раз
        public static void zadanie1(int N)
        {
            Console.Write("\nСлова, которые встречаются больше " + N + "раз\n");
            int num = 0;
            String output = "";
            for (int i = 0; i < words.Count; i++)
            {
                if (words[i].calculateMatches() > N)
                {
                    output += words[i].Thisword + " (" + words[i].calculateMatches() + ")\n";
                    num++;
                }
            }
            Console.Write(output);
            if (num == 0)
                Console.Write("Такие слова отсутствуют.\n");
        }

        //2) слова в алфавитном порядке
        public static void zadanie2()
        {
            Console.Write("Слова в алфавитном порядке:\n");
            // https://support.microsoft.com/ru-ru/help/320727/how-to-use-the-icomparable-and-icomparer-interfaces-in-visual-c
            words.Sort(); //сортируем массив (используется метод CompareTo из класса Word)
            for (int i = 0; i < words.Count; i++)
            {
                Console.Write(words[i].Thisword + " ");
            }
            Console.WriteLine();
        }

        //3 
        public static void zadanie3(int index)
        {
            try
            {
                String pages = words[index].showPages(words[index].getUniquePages());
                if (pages == "")
                {
                    Console.Write("Слово \"" + words[index].Thisword + "\" не встречается ни на одной странице\n");
                }
                else
                {
                    Console.Write("Слово \"" + words[index].Thisword + "\" встречается на страницах:\n" + pages + "\n");
                }
            }
            catch (System.ArgumentOutOfRangeException e)
            {
                Console.Write("\nИндекс находится за пределами массива слов.\n");
            }
            catch
            {
                Console.Write("\nПроизошла ошибка...\n");
            }
        }
    }
}
